# Virage Grow A Garden Macro
A macro for the Roblox game "Grow a Garden"

 ## Installation
 - First of all, you need to download [AutoHotKey v1.1](https://www.autohotkey.com/) (Not 2.0), and run the installer
 - Once complete, download the most recent version of the Virage Grow A Garden Macro through the most recent [GitHub Release](https://github.com/VirageRoblox/Virage-Grow-A-Garden-Macro/releases/latest)(Download source code ZIP)
 - After downloading, extract the ZIP file to your desired directory

Before starting the macro:
- ensure you **extracted** the macro file
- **don't** go full screen, be in windowed fullscreen
- Set your roblox camera mode to the following --> **default(classic)**
- put "Recall Wrench" in the **2nd hot bar slot** --> macro may bug out and not automatically do it
- have 5-10 things in your hotbar
- make sure UI Navigation is turned **ON** in your Roblox settings
- unequip your **“grey mouse” pet** if you have some equipped since they give you a speed bonus that will break the macro

## Features
Virage Grow A Garden Macro has a couple of different features it is capable of. These include:
- Automatic buying from all Shops, with the options to check the items you want the macro to purchase
- Discord Webhook integration
- Multi-alts macroing
- Fast mode/Slow mode

 Discord Server: [https://discord.com/VirageMacros](https://discord.com/invite/BPPSAG8MN5)
